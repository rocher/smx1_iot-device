const unsigned int LED_MQTT_IN   =  9;
const unsigned int LED_MQTT_OUT  = 10;
const unsigned int LED_TEMP_READ = 11;
const unsigned int LED_CONNECT   = 12;

const unsigned int PIN_DHT22     = 28;
const unsigned int PIN_ONE_WIRE  = 13;